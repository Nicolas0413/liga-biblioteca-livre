import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import {
  IonButton, IonButtons, IonContent, IonHeader, IonTitle, IonToolbar,
} from '@ionic/angular';
import { AuthService } from '../auth.service';
import { LivroService } from '../livro.service';
import {
  FILTROS_LIVRO, FiltroLivro, ResultadoEmprestimo, ROTULO_STATUS,
} from '../models';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [IonButton, IonButtons, IonContent, IonHeader, IonTitle, IonToolbar],
})
export class HomePage {
  private auth = inject(AuthService);
  private router = inject(Router);
  private livroService = inject(LivroService);

  livros = this.livroService.livrosFiltrados;
  totais = this.livroService.totais;
  filtro = this.livroService.filtro;

  filtros = FILTROS_LIVRO;
  rotulo = ROTULO_STATUS;
  aviso = signal<ResultadoEmprestimo | null>(null);

  filtrar(f: FiltroLivro) {
    this.livroService.definirFiltro(f);
  }

  emprestar(id: string) {
    this.aviso.set(this.livroService.emprestar(id));
  }

  async sair() {
    await this.auth.sair();
    await this.router.navigateByUrl('/login', { replaceUrl: true });
  }
}
