import { Injectable, computed, signal } from '@angular/core';
import {
  FiltroLivro, Livro, ResultadoEmprestimo, TotaisLivros,
} from './models';

@Injectable({ providedIn: 'root' })
export class LivroService {
  private readonly _livros = signal<Livro[]>([
    { id: '1', titulo: 'Ordem Paranormal RPG', status: 'disponivel' },
    { id: '2', titulo: 'Vampiro a Máscara', status: 'disponivel' },
    { id: '3', titulo: 'Umineko When They Cry', status: 'emprestado' },
    { id: '4', titulo: 'Fábula Úlmtima', status: 'disponivel' },
    { id: '5', titulo: 'Tormenta 20', status: 'indisponivel' },
  ]);
  private readonly _filtro = signal<FiltroLivro>('todos');

  /** Estado só de leitura para quem consome. */
  readonly livros = this._livros.asReadonly();
  readonly filtro = this._filtro.asReadonly();

  readonly livrosFiltrados = computed<Livro[]>(() => {
    const f = this._filtro();
    return f === 'todos'
      ? this._livros()
      : this._livros().filter((l) => l.status === f);
  });

  readonly totais = computed<TotaisLivros>(() => {
    const lista = this._livros();
    const conta = (s: Livro['status']) => lista.filter((l) => l.status === s).length;
    return {
      total: lista.length,
      disponiveis: conta('disponivel'),
      emprestados: conta('emprestado'),
      indisponiveis: conta('indisponivel'),
    };
  });

  definirFiltro(filtro: FiltroLivro): void {
    this._filtro.set(filtro);
  }

  /** Regra principal: só livro disponível pode ser emprestado. */
  emprestar(id: string): ResultadoEmprestimo {
    const livro = this._livros().find((l) => l.id === id);

    if (!livro) {
      return { ok: false, mensagem: 'Livro não encontrado' };
    }
    if (livro.status === 'emprestado') {
      return { ok: false, mensagem: 'Este livro já está emprestado' };
    }
    if (livro.status === 'indisponivel') {
      return { ok: false, mensagem: 'Este livro está indisponível' };
    }

    this._livros.update((lista) =>
      lista.map((l) => (l.id === id ? { ...l, status: 'emprestado' } : l)),
    );
    return { ok: true, mensagem: 'Empréstimo registrado' };
  }
}
