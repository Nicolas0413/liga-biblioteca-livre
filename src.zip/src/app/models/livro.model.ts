export type StatusLivro = 'disponivel' | 'emprestado' | 'indisponivel';

export interface Livro {
  id: string;
  titulo: string;
  status: StatusLivro;
}

/** Texto exibido no badge, como no print. */
export const ROTULO_STATUS: Record<StatusLivro, string> = {
  disponivel: 'disponível',
  emprestado: 'emprestado',
  indisponivel: 'indisponível',
};

export type FiltroLivro = 'todos' | StatusLivro;

export interface TotaisLivros {
  total: number;
  disponiveis: number;
  emprestados: number;
  indisponiveis: number;
}

export interface ResultadoEmprestimo {
  ok: boolean;
  mensagem: string;
}

export const FILTROS_LIVRO: { valor: FiltroLivro; rotulo: string }[] = [
  { valor: 'todos', rotulo: 'Todos' },
  { valor: 'disponivel', rotulo: 'Disponíveis' },
  { valor: 'emprestado', rotulo: 'Emprestados' },
  { valor: 'indisponivel', rotulo: 'Indisponíveis' },
];
